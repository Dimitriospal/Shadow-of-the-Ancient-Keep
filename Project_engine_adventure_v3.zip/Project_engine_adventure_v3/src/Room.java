import java.util.Map;
import java.util.List;

public class Room {
    public String id;
    public String description; // Η περιγραφή του χώρου [cite: 38]
    public Map<String, String> exits; // Πού οδηγεί κάθε κατεύθυνση (π.χ. "north" -> "hallway") [cite: 38]
    public List<String> items; // Λίστα με τα IDs των αντικειμένων που υπάρχουν εδώ [cite: 38]
}