import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GameLoader loader = new GameLoader();
        Scanner scanner = new Scanner(System.in); // Προσθήκη Scanner για την Εβδ. 3

        try {
            List<Room> rooms = loader.loadRooms("src/main/resources/world.json");
            Player player = new Player();
            player.setCurrentRoom(rooms.get(0));

            System.out.println("--- Progress Update: Week 3 Interaction ---");

            // Απλό Game Loop
            boolean running = true;
            while (running) {
                System.out.println("\n" + player.getCurrentRoom().description);
                // Αυτό τυπώνει τις διαθέσιμες εξόδους αυτόματα από το Map του Κώστα
                System.out.println("Έξοδοι: " + player.getCurrentRoom().exits.keySet());
                System.out.println("Που θα πας:");

                String input = scanner.nextLine().toLowerCase();

                if (input.equals("exit")) {
                    running = false;
                } else if (input.startsWith("go ")) {
                    String direction = input.substring(3).trim(); // Εντολή go
                    // Έλεγχος αν υπάρχει η κατεύθυνση στο JSON
                    if (player.getCurrentRoom().exits.containsKey(direction)) {
                        String nextRoomId = player.getCurrentRoom().exits.get(direction);

                        // Ενημέρωση τοποθεσίας παίκτη
                        for (Room r : rooms) {
                            if (r.id.equals(nextRoomId)) {
                                player.setCurrentRoom(r);
                                System.out.println("Μετακινήθηκες προς: " + direction);
                                break;
                            }
                        }
                    } else {
                        System.out.println("Σφάλμα: Δεν υπάρχει έξοδος στα " + direction + "!");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Σφάλμα: " + e.getMessage());
        }
    }
}